#!/bin/bash
R -f ko_efficiency_analysis_code.R
python scwat_koe_pcr.py
R -f correlation_analysis.R

